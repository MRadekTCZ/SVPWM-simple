/*
 * SVPWM.c
 *
 *  Created on: Nov 25, 2024
 *      Author: brzycki
 */
#include "SVPWM.h"
SVPWM svPWM(float Ud, float Uq, float theta, float U_dc)
{
    SVPWM duty_cycles;
    float u_alfa;
    float u_beta;
    int sektor; // actual sector of PLL theta (1 of 6);
    float u_alfa_1; //part of alfa vector
    float u_alfa_2; //part of beta vector
    float u_beta_1;
    float u_beta_2;
    float U_max; //Maximum amplitude (Upper modulation limit) - dependent on Udc voltage
    float PWM_vector_1[3];
    float PWM_vector_2[3];
    float PWM_vector_0[3];
    const short int OUT[6][3] = { {1,0,0},{1,1,0},{0,1,0},{0,1,1},{0,0,1},{1,0,1} }; //space vectors
    //We need only 3 transistor states, but I want to start indexing from 1 to be consinstant with theory in paper. Compiler will book space in memory for even number of bytes anyway.
    unsigned short int T1[3 + 1];
    unsigned short int T2[3 + 1];
    unsigned short int T0[3 + 1];
    float time1_vector, time2_vector, time0_vector;

    //Modulation limit - This part is also optional but suggested
    /*******/
    U_max = U_dc*one_by_sqrt3;
    if(Ud>U_max)Ud = U_max;
    else if(Ud<U_max*0.1) Ud = U_max*0.1;
    if(Uq>U_max)Uq = U_max;
    /*******/

    //DQ to alfa beta transformation
    u_alfa = Ud * cosf(theta) - Uq * sinf(theta);
    u_beta = Ud * sinf(theta) + Uq * cosf(theta);


    //Determination of two main vectors V1 and V2 and their alfa beta component parts
    sektor = floorf(theta * one_by_pi_by_3);
    switch (sektor)
    {
    case 0:
        u_alfa_1 = sqrt2_by_sqrt3 * U_dc;
        u_beta_1 = 0;
        u_alfa_2 = one_by_sqrt6 * U_dc;
        u_beta_2 = one_by_sqrt2 * U_dc;
        break;
    case 1:
        u_alfa_1 = one_by_sqrt6 * U_dc;
        u_beta_1 = one_by_sqrt2 * U_dc;
        u_alfa_2 = -one_by_sqrt6 * U_dc;
        u_beta_2 = one_by_sqrt2 * U_dc;
        break;
    case 2:
        u_alfa_1 = -one_by_sqrt6 * U_dc;
        u_beta_1 = one_by_sqrt2 * U_dc;
        u_alfa_2 = -sqrt2_by_sqrt3 * U_dc;
        u_beta_2 = 0;
        break;
    case 3:
        u_alfa_1 = -sqrt2_by_sqrt3 * U_dc;
        u_beta_1 = 0;
        u_alfa_2 = -one_by_sqrt6 * U_dc;
        u_beta_2 = -one_by_sqrt2 * U_dc;
        break;
    case 4:
        u_alfa_1 = -one_by_sqrt6 * U_dc;
        u_beta_1 = -one_by_sqrt2 * U_dc;
        u_alfa_2 = one_by_sqrt6 * U_dc;
        u_beta_2 = -one_by_sqrt2 * U_dc;
        break;
    case 5:
        u_alfa_1 = one_by_sqrt6 * U_dc;
        u_beta_1 = -one_by_sqrt2 * U_dc;
        u_alfa_2 = sqrt2_by_sqrt3 * U_dc;
        u_beta_2 = 0;
        break;
    }

    //Calculating time vectors
    time1_vector = (u_alfa * u_beta_2 - u_beta * u_alfa_2) / (u_alfa_1 * u_beta_2 - u_beta_1 * u_alfa_2);
    time2_vector = ((-u_alfa * u_beta_1 + u_beta * u_alfa_1) / (u_alfa_1 * u_beta_2 - u_beta_1 * u_alfa_2));
    time0_vector = (1 - time1_vector - time2_vector);

    //First sector part V1
    T1[1] = OUT[sektor][0];
    T1[2] = OUT[sektor][1];
    T1[3] = OUT[sektor][2];

    PWM_vector_1[0] = T1[1] * time1_vector;
    PWM_vector_1[1] = T1[2] * time1_vector;
    PWM_vector_1[2] = T1[3] * time1_vector;

    //Second sector part V2
    if (sektor == 5)
    {
        T2[1] = OUT[0][0];
        T2[2] = OUT[0][1];
        T2[3] = OUT[0][2];
    }
    else
    {
        T2[1] = OUT[sektor + 1][0];
        T2[2] = OUT[sektor + 1][1];
        T2[3] = OUT[sektor + 1][2];

    }
    PWM_vector_2[0] = T2[1] * time2_vector;
    PWM_vector_2[1] = T2[2] * time2_vector;
    PWM_vector_2[2] = T2[3] * time2_vector;

    /******/
    //V0 - zero vector part - optional part for less transistor switching. Don't have to be added.
    //If majority of transistors is ON (maximum total wage of three vectors is 3.0, so it has to be greater than 1.5) then OFF vector is (1,1,1)
    if ((PWM_vector_1[0] + PWM_vector_2[0] + PWM_vector_1[1] + PWM_vector_2[1] + PWM_vector_1[2] + PWM_vector_2[2]) > 1.5f)
    {
        T0[1] = 1;
        T0[2] = 1;
        T0[3] = 1;
    }
    else
    {
        T0[1] = 0;
        T0[2] = 0;
        T0[3] = 0;
    }
    /******/

    PWM_vector_0[0] = T0[1] * time0_vector;
    PWM_vector_0[1] = T0[2] * time0_vector;
    PWM_vector_0[2] = T0[3] * time0_vector;

    //Sum of time vectors
    duty_cycles.d1d4 = PWM_vector_1[0] + PWM_vector_2[0] + PWM_vector_0[0];
    duty_cycles.d2d5 = PWM_vector_1[1] + PWM_vector_2[1] + PWM_vector_0[1];
    duty_cycles.d3d6 = PWM_vector_1[2] + PWM_vector_2[2] + PWM_vector_0[2];
    duty_cycles.t0 = time0_vector;
    duty_cycles.t1 = time1_vector;
    duty_cycles.t2 = time2_vector;
    return duty_cycles;
}



