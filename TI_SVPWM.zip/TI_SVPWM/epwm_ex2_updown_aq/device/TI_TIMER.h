/*
 * TI_TIMER.h
 *
 *  Created on: Nov 25, 2024
 *      Author: brzycki
 */

#ifndef DEVICE_TI_TIMER_H_
#define DEVICE_TI_TIMER_H_
#include "driverlib.h"
#include "device.h"
#include "board.h"
void initCPUTimers(uint16_t *cpuTimer0IntCount);
void configCPUTimer(uint32_t, float, float, uint16_t *cpuTimer0IntCount);



#endif /* DEVICE_TI_TIMER_H_ */
