/*
 * TI_PWM.h
 *
 *  Created on: Nov 25, 2024
 *      Author: brzycki
 */

#ifndef CPU1_RAM_DEVICE_TI_PWM_H_
#define CPU1_RAM_DEVICE_TI_PWM_H_
#include "driverlib.h"
#include "device.h"
#include "board.h"
//
// Defines
//
#define EPWM1_TIMER_TBPRD  10000U
#define EPWM1_MAX_CMPA     9999U
#define EPWM1_MIN_CMPA       0U
#define EPWM1_MAX_CMPB     9999U
#define EPWM1_MIN_CMPB       0U

#define EPWM_CMP_UP           1U
#define EPWM_CMP_DOWN         0U

typedef struct
{
    uint32_t epwmModule;
    uint16_t epwmCompADirection;
    uint16_t epwmCompBDirection;
    uint16_t epwmTimerIntCount;
    uint16_t epwmMaxCompA;
    uint16_t epwmMinCompA;
    uint16_t epwmMaxCompB;
    uint16_t epwmMinCompB;
}epwmInformation;

void initEPWM1(epwmInformation *epwmInfo);
void initEPWM2(epwmInformation *epwmInfo);
void initEPWM3(epwmInformation *epwmInfo);
void setupEPWMActiveHigh(uint32_t base);
void setupEPWMActiveLow(uint32_t base);
void setupEPWMActiveHighComplementary(uint32_t base);
void setupEPWMActiveLowComplementary(uint32_t base);
void setupEPWMOutputSwap(uint32_t base);


#endif /* CPU1_RAM_DEVICE_TI_PWM_H_ */
